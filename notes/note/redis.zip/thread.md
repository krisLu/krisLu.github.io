---
layout: wiki
wiki: Notes
breadcrumb: false
title: 多线程
order: 201
comments: false
menu_id: notes
---



### 自定义线程池

场景：由于业务线的线程池很多，每次都需要一个threadpool。所以需要对特定的线程池定制化

```java
 @Configuration
public class ThreadPollConfig{
    @Bean(name="mailThreadPool")
    public ThreadExectorPool getMailThreadPool(){
        //如果不传入线程工厂，底层就会使用默认的线程工厂
        return new ThreadExectorPool(20, 50, 10,
                                     TimeUnit.SECONDS, new LinkedBlockLingQueue<>(), 
                                     new ThreadPoolExecutor.CallerRunsPolicy())
    }
}
```

测试使用自定义线程

```java
@Resource(name= "mailThreadPool")
private ThreadExectorPool mailThreadPool;
@Test
void test(){
       for (int i = 0; i < 10; i++) {
            mailThreadPool.submit(new Runnable() {
                @Override
                public void run() {
                    log.info("当前时间:" + System.currentTimeMillis());
                }
            });
        }
   
}
```

问题：打印日志无法辨识是哪一个线程池所产生的，没有辨识度。所以需要引入自定义线程工厂

### 自定义线程工厂

```java
public class MailThreadFactory implement ThreadFactiory(){

    //多线程环境保证变量的原子性，使用AtomicInteger
    private final AtomicInteger poolNumber = new AtomicInteger(1);

    private final ThreadGroup threadGroup;

    private final AtomicInteger threadNumber = new AtomicInteger(1);

    public final String namePrefix;

    CustomNameThreadFactory(String name) {
        SecurityManager s = System.getSecurityManager();
        threadGroup = (s != null) ? s.getThreadGroup() :
                Thread.currentThread().getThreadGroup();
        if (null == name || "".equals(name.trim())) {
            name = "pool";
        }
        //自定义逻辑，拼接线程name
        namePrefix = name + "-" +
                poolNumber.getAndIncrement() +
                "-thread-";
    }

    @Override
    public Thread newThread(Runnable r) {
        Thread t = new Thread(threadGroup, r,
                namePrefix + threadNumber.getAndIncrement(),
                0);
        //判断是否守护线程
        if (t.isDaemon())
            t.setDaemon(false);
        //优先级	
        if (t.getPriority() != Thread.NORM_PRIORITY)
            t.setPriority(Thread.NORM_PRIORITY);
        return t;
    }

}
```

### 异步线程池封装

目的： 异步执行task的时候，我可以进行异步执行，当执行结果阻塞可以返回默认值，且不形象其他的线程执行结果

```java
/**
 * 异步future工具类封装
 *
 * @author: ChickenWing
 * @date: 2023/1/15
 */
public class CompletableFutureUtils {

    /**
     * 获取future返回结果
     */
    public static <T> T getResult(Future<T> future, long timeout, TimeUnit timeUnit, T defaultValue, Logger logger) {
        //超时返回默认结果
        try {
            return future.get(timeout, timeUnit);
        } catch (Exception e) {
            logger.error("CompletableFutureUtils.getResult.error:{},defaultValue:{}", e.getMessage(), e);
            logger.error("CompletableFutureUtils.getResult.error.returnDefaultValue:{}", defaultValue);
            return defaultValue;
        }
    }

}

```

测试类：

```java
 @Test
    public void testFuture() {
        List<FutureTask<String>> futureTaskList = new LinkedList<>();
        FutureTask futureTask1 = new FutureTask<String>(() -> {
            return "鸡翅";
        });
        FutureTask futureTask2 = new FutureTask<String>(() -> {
            Thread.sleep(2000);
            return "经典";
        });
        futureTaskList.add(futureTask1);
        futureTaskList.add(futureTask2);
        mailThreadPool.submit(futureTask1);
        mailThreadPool.submit(futureTask2);

        for (int i = 0; i < futureTaskList.size(); i++) {
            String name = CompletableFutureUtils.getResult(futureTaskList.get(i),
                    1, TimeUnit.SECONDS, "经典鸡翅", log);
            log.info("MailThreadPoolTest.name:{}",name);
        }

    }
```

### 线程池两种关闭方式 

通过executer.shutdown（）方法进行关闭，isShutDown（）方法可以观看线程池是否关闭

```java
@SpringBootTest(classes = DemoApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@RunWith(SpringRunner.class)
@Slf4j
public class ThreadPoolShutDownTest {

    @Test
    public void testShutDown() throws Exception {
        ExecutorService executorService = Executors.newFixedThreadPool(10);
        for (int i = 0; i < 1000; i++) {
            executorService.execute(new TaskShutDownPool());
        }
        Thread.sleep(1000);

        log.info("ThreadPoolShutDownTest.testShutDown.status:{}", executorService.isShutdown() + ",调用 shutdown() 方法之前");
        executorService.shutdown();
        log.info("ThreadPoolShutDownTest.testShutDown.status:{}", executorService.isShutdown() + ",调用 shutdown() 方法之后");
        Thread.sleep(500);
        log.info("ThreadPoolShutDownTest.testShutDown");
        executorService.execute(new TaskShutDownPool());
    }


    class TaskShutDownPool implements Runnable {
        @Override
        public void run() {
            try {
                Thread.sleep(500);
                log.info(Thread.currentThread().getName());
            } catch (InterruptedException e) {
                log.info("TaskShutDownPool.interrupted:{}", e.getMessage(), e);
            }
        }
    }

}

```

运行结果：

![image-20230922142001991](ape-frame.assets/image-20230922142001991.png)

**结论：**shutdown方法不会让线程池立刻关闭，而是将正在执行的任务和等待执行的任务全部执行完，然后在进行关闭

### isShutdown和isTerminated方法的区别

isShutdown()方法判断是否关闭，而isTerminated()方法判断线程池整体的任务完全执行结束

### shutdown()和shutdownNow()方法的区别

shutdown()方法终止线程池继续在添加新的任务，当所有等待的以及正在执行的任务完成后关闭线程池，而shutdownNow()方法是立刻关闭线程池，无论是否正在执行任务，都会抛出InterruptException异常

### 合理的关闭线程池

封装关闭线程池的工具类

```java
public class ThreadShutDownUtil{
    private ThreadShutDownUtil();
    
    public static void shutdownPool(ExecutorService pool, int shutDownTimeOut, int shutDownNowtimOut, TimeUnit timeunit){
        pool.shutdown();
        try{
            if(!pool.awitTermination(10L, timeUnit)){
                pool.shutdownNow();
                if(!pool.awitTermination(10L, timeUnit)){
                    log.error("ThreadPoolUtils.shutDownPool.error");
                }
            }catch(InterrupterException e){
                log.error("ThreadPoolUtils.shutDownPool.interrupt.error:{}", e.getMessage(), e);
                pool.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
    }
}
```



